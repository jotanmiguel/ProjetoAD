Funções:
- search: 50%
- filter: 0%
- filter diversify: 0%
- details: 90% (No teste disponibilizado pelo prof., o custo da viagem é diferente do esperado)

cliente.py: 20%
- acho que o search funciona, mas nao tenho certeza

servidor.py: 50%
- details so funciona depois de search
- filter nao funciona
- filter diversify nao funciona
- search funciona mas com problemas (retorna um numero diferente de viagens do que o esperado, )
